import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "PQC Learning Path — Post-Quantum Cryptography",
  description: "An interactive guided learning experience from cryptographic foundations to post-quantum deployment. By Paul Lester, Leon County Public Library.",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="anonymous" />
        <link href="https://fonts.googleapis.com/css2?family=JetBrains+Mono:wght@400;600&family=Outfit:wght@300;400;500;600;700;800&family=Source+Serif+4:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap" rel="stylesheet" />
      </head>
      <body className="grain">
        <div className="mesh-bg" />
        {children}
      </body>
    </html>
  );
}
